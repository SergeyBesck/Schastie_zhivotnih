-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Мар 10 2024 г., 21:57
-- Версия сервера: 5.7.39
-- Версия PHP: 8.0.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `schastie_zhivotnih`
--

-- --------------------------------------------------------

--
-- Структура таблицы `hoziain_zhivotnogo`
--

CREATE TABLE `hoziain_zhivotnogo` (
  `id_hoziain_zhivotnogo` int(11) NOT NULL,
  `fio` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adres` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `med_karta`
--

CREATE TABLE `med_karta` (
  `id_karta` int(11) NOT NULL,
  `id_zhivotnie` int(11) NOT NULL,
  `id_hoziain_zhivotnogo` int(11) NOT NULL,
  `id_vrach` int(11) NOT NULL,
  `id_uslugi` int(11) NOT NULL,
  `diagnoz` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `naznachenie` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `role` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login` varchar(140) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `uslugi`
--

CREATE TABLE `uslugi` (
  `id_uslugi` int(11) NOT NULL,
  `name_uslugi` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coust` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `vrach`
--

CREATE TABLE `vrach` (
  `id_vrach` int(11) NOT NULL,
  `fio` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telphone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `zhivotnie`
--

CREATE TABLE `zhivotnie` (
  `id_zhivotnie` int(11) NOT NULL,
  `id_hoziain_zhivotnogo` int(11) NOT NULL,
  `clichka` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `poroda` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pol` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `hoziain_zhivotnogo`
--
ALTER TABLE `hoziain_zhivotnogo`
  ADD PRIMARY KEY (`id_hoziain_zhivotnogo`);

--
-- Индексы таблицы `med_karta`
--
ALTER TABLE `med_karta`
  ADD PRIMARY KEY (`id_karta`),
  ADD KEY `id_hoziain_zhivotnogo` (`id_hoziain_zhivotnogo`),
  ADD KEY `id_uslugi` (`id_uslugi`),
  ADD KEY `id_vrach` (`id_vrach`),
  ADD KEY `id_zhivotnie` (`id_zhivotnie`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- Индексы таблицы `uslugi`
--
ALTER TABLE `uslugi`
  ADD PRIMARY KEY (`id_uslugi`);

--
-- Индексы таблицы `vrach`
--
ALTER TABLE `vrach`
  ADD PRIMARY KEY (`id_vrach`);

--
-- Индексы таблицы `zhivotnie`
--
ALTER TABLE `zhivotnie`
  ADD PRIMARY KEY (`id_zhivotnie`),
  ADD KEY `id_hoziain_zhivotnogo` (`id_hoziain_zhivotnogo`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `hoziain_zhivotnogo`
--
ALTER TABLE `hoziain_zhivotnogo`
  MODIFY `id_hoziain_zhivotnogo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `med_karta`
--
ALTER TABLE `med_karta`
  MODIFY `id_karta` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `uslugi`
--
ALTER TABLE `uslugi`
  MODIFY `id_uslugi` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `vrach`
--
ALTER TABLE `vrach`
  MODIFY `id_vrach` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `zhivotnie`
--
ALTER TABLE `zhivotnie`
  MODIFY `id_zhivotnie` int(11) NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `med_karta`
--
ALTER TABLE `med_karta`
  ADD CONSTRAINT `med_karta_ibfk_1` FOREIGN KEY (`id_hoziain_zhivotnogo`) REFERENCES `hoziain_zhivotnogo` (`id_hoziain_zhivotnogo`),
  ADD CONSTRAINT `med_karta_ibfk_2` FOREIGN KEY (`id_uslugi`) REFERENCES `uslugi` (`id_uslugi`),
  ADD CONSTRAINT `med_karta_ibfk_3` FOREIGN KEY (`id_vrach`) REFERENCES `vrach` (`id_vrach`),
  ADD CONSTRAINT `med_karta_ibfk_4` FOREIGN KEY (`id_zhivotnie`) REFERENCES `zhivotnie` (`id_zhivotnie`);

--
-- Ограничения внешнего ключа таблицы `zhivotnie`
--
ALTER TABLE `zhivotnie`
  ADD CONSTRAINT `zhivotnie_ibfk_1` FOREIGN KEY (`id_hoziain_zhivotnogo`) REFERENCES `hoziain_zhivotnogo` (`id_hoziain_zhivotnogo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
