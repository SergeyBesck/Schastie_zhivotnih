<?php
global $mysqli;
include 'template/database.php';
?>
<?php
if (!empty($_POST)) {
//В переменные запишем данные, полученные с формы

    $data = $_POST['data'];
    $name_uslugi = $_POST['name_uslugi'];
    $fio = $_POST['fio'];
    $clichka = $_POST['clichka'];
    $poroda = $_POST['poroda'];
    $pol = $_POST['pol'];

//В переменную $sql запишем запрос на добавление записи в таблицу ГРУППА	
    $sql = "INSERT INTO users(data, login, password) VALUES ('$role', '$login', '$password')";
//Выполнить запрос

    if ($mysqli->query($sql)) {
        echo "Вы записаны на $data";
    } else {
        echo "Ошибка: " . $mysqli->error;
    }

}

?>

<form method="POST">
    <label for="data" class="form-label">Дата</label>
    <input type="data" class="form-control" id="data" name="data">
    <label for="name_uslugi" class="form-label">Название услуг</label>
    <input type="text" class="form-control" id="name_uslugi" name="name_uslugi">
    <label for="fio" class="form-label">ФИО</label>
    <input type="text" class="form-control" id="fio" name="fio">
    <label for="clichka" class="form-label">Кличка</label>
    <input type="text" class="form-control" id="clichka" name="clichka">
    <label for="poroda" class="form-label">Порода</label>
    <input type="text" class="form-control" id="poroda" name="poroda">
    <label for="pol" class="form-label">Пол</label>
    <input type="text" class="form-control" id="pol" name="pol">
    <button type="submit" class="btn btn-primary">Отправить</button>
</form>
