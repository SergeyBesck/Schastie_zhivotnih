<?php
global $mysqli;
include 'template/head.php';
include 'template/database.php';
include 'template/nav.php';
?>

<?php
if (!empty($_POST)) {
//В переменные запишем данные, полученные с формы

    $role = $_POST['role'];
    $login = $_POST['login'];
    $password = $_POST['password'];


//В переменную $sql запишем запрос на добавление записи в таблицу ГРУППА	
    $sql = "INSERT INTO users(role, login, password) VALUES ('$role', '$login', '$password')";
//Выполнить запрос

    if ($mysqli->query($sql)) {
        echo "Данные успешно добавлены";
    } else {
        echo "Ошибка: " . $mysqli->error;
    }
}
?>
    <form method="POST">
        <div class="container mb-5">
            <div class="row">
                <div class="mb-3">
                    <label for="role" class="form-label">Роль</label>
                    <select type="text" class="form-control" id="role" name="role">
                        <option value="Администратор">Администратор</option>
                        <option value="Бухгалтер">Бухгалтер</option>
                        <option value="Врач">Врач</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="login" class="form-label">Логин</label>
                    <input type="text" class="form-control" id="login" name="login">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Пароль</label>
                    <input type="password" class="form-control" id="password" name="password">
                </div>

                <button type="submit" class="btn btn-primary">Отправить</button>
            </div>
        </div>
    </form>
<?php
include 'template/footer.php';
