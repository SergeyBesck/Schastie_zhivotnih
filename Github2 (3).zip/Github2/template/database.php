<?php
$mysqli=new mysqli ("localhost", "root", "","Schastie_zhivotnih");
$mysqli->set_charset("utf8");
?>