<?php
global $mysqli;
include 'template/head.php';
include 'template/database.php';
include 'template/nav.php';
?>

<?php
if (!empty($_POST)) {
//В переменные запишем данные, полученные с формы

    $role = $_POST['role'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $petName = $_POST['petName'];
    $poroda = $_POST['poroda'];
    $sex = $_POST['sex'];

//В переменную $sql запишем запрос на добавление записи в таблицу ГРУППА
    $sql = "INSERT INTO hoziain_zhivotnogo(fio, adres, telephone, password) VALUES ('$name', '$address', '$phone', '$password')";

//Выполнить запрос
    $success1 = $mysqli->query($sql);

    $hoziain_id = "SELECT id_hoziain_zhivotnogo FROM hoziain_zhivotnogo ORDER BY id_hoziain_zhivotnogo DESC LIMIT 1";
    $result = mysqli_query($mysqli, $hoziain_id);

    if ($result) {
        $hoziain_id = mysqli_fetch_assoc($result)['id_hoziain_zhivotnogo'];
    } else {
        echo "Ошибка: не найдено ни одной записи";
        exit;
    }

    $id = $hoziain_id;

    $sql2 = "INSERT INTO zhivotnie(id_hoziain_zhivotnogo, clichka, poroda, pol) VALUES ($id, '$petName', '$poroda', '$sex')";

//Выполнить запрос
    $success2 = $mysqli->query($sql2);

    if ($success1 && $success2) {
        echo "Данные успешно добавлены";
    } else {
        echo "Ошибка: " . $mysqli->error;
    }
}
?>
    <form method="POST">
        <div class="container mb-5">
            <div class="row">
                <h2 style="margin: 0 0 15px">Данные клиента</h2>
                <div class="mb-3">
                    <label for="role" class="form-label">Роль</label>
                    <select type="text" class="form-control" id="role" name="role">
                        <option value="Администратор">Клиент</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="name" class="form-label">ФИО</label>
                    <input type="text" class="form-control" id="name" name="name">
                </div>
                <div class="mb-3">
                    <label for="address" class="form-label">Адрес</label>
                    <input type="text" class="form-control" id="address" name="address">
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label">Телефон</label>
                    <input type="phone" class="form-control" id="phone" name="phone">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Пароль</label>
                    <input type="password" class="form-control" id="password" name="password">
                </div>
                <div class="mb-3">
                    <hr style="margin: 40px 0">
                </div>
                <h2 style="margin: 0 0 15px">Данные вашего питомца</h2>
                <div class="mb-3">
                    <label for="petName" class="form-label">Кличка</label>
                    <input type="text" class="form-control" id="petName" name="petName">
                </div>
                <div class="mb-3">
                    <label for="poroda" class="form-label">Порода</label>
                    <input type="text" class="form-control" id="poroda" name="poroda">
                </div>
                <div class="mb-3">
                    <label for="sex" class="form-label">Пол</label>
                    <select type="sex" class="form-control" id="sex" name="sex">
                        <option value="Мужской">Мужской</option>
                        <option value="Женский">Женский</option>
                    </select>
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-primary">Отправить</button>
                </div>
            </div>
        </div>
    </form>
<?php
include 'template/footer.php';